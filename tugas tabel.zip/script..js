const x ="Belajar Javascript";
let a= 23;  
var b= true;

console.log(x);
console.log(a);
console.log(b);