var x "Belajar Merdeka";

console.log(x);